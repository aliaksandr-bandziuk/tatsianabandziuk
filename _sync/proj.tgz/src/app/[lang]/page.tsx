import type { Metadata } from "next";
import { getHomepage } from "@/sanity/sanity.utils";
import { LOCALES } from "@/lib/site";

export function generateStaticParams() {
  return LOCALES.map((lang) => ({ lang }));
}

export async function generateMetadata({ params }: { params: { lang: string } }): Promise<Metadata> {
  return {
    alternates: {
      canonical: params.lang === "en" ? "/" : `/${params.lang}`,
      languages: { en: "/", pl: "/pl", ru: "/ru", "x-default": "/" },
    },
  };
}

/**
 * Temporary home page: proves routing, fonts, tokens and the Sanity
 * connection. Replaced by the real sections in the next step.
 */
export default async function Home({ params }: { params: { lang: string } }) {
  let homepage: { heroTitle?: string } | null = null;
  let sanityError = "";
  try {
    homepage = await getHomepage(params.lang);
  } catch (err) {
    sanityError = err instanceof Error ? err.message : String(err);
  }

  return (
    <main className="container" style={{ paddingBlock: "var(--section)" }}>
      <p className="mono" style={{ fontSize: 12, letterSpacing: "0.12em", color: "var(--text-tertiary)" }}>
        WARSAW · EN / PL / RU · {params.lang.toUpperCase()}
      </p>
      <h1 style={{ fontSize: "clamp(40px, 6vw, 72px)", marginTop: 16 }}>
        Tatsiana Bandziuk,
        <br />
        <em style={{ color: "var(--accent)" }}>Retail and Fashion Analytics</em> Consultant
      </h1>
      <p style={{ marginTop: 24, color: "var(--text-secondary)" }}>
        Setup check. Sanity:{" "}
        {sanityError
          ? `error — ${sanityError}`
          : homepage
            ? `connected, home page found (“${homepage.heroTitle ?? "no hero title yet"}”)`
            : "connected, no home page document for this language yet"}
      </p>
      <p className="hand" style={{ marginTop: 16, fontSize: 24, color: "var(--accent)" }}>
        Татьяна Бандюк · Tatsiana · zażółć gęślą jaźń
      </p>
    </main>
  );
}
