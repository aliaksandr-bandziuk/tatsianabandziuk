export default function Loading() {
  return (
    <div className="loader-wrapper" aria-busy="true" aria-live="polite">
      <span className="loader" />
    </div>
  );
}
