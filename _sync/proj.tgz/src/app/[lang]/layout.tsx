import "@/app/globals.css";
import type { Metadata, Viewport } from "next";
import { notFound } from "next/navigation";
import { Playfair_Display, Inter_Tight, IBM_Plex_Mono, Caveat } from "next/font/google";
import CustomCookieConsent from "../components/shared/CustomCookieConsent/CustomCookieConsent";
import GoogleAnalyticsWrapper from "../components/scripts/GoogleAnalyticsWrapper/GoogleAnalyticsWrapper";
import MicrosoftClarity from "../components/scripts/MicrosoftClarity/MicrosoftClarity";
import SchemaIdentity from "../components/seo/SchemaIdentity/SchemaIdentity";
import { LOCALES, SITE_NAME, SITE_URL, isLocale } from "@/lib/site";

// Every font carries Cyrillic and Polish diacritics: the site is EN / PL / RU.
const fontHeading = Playfair_Display({
  subsets: ["latin", "latin-ext", "cyrillic"],
  weight: ["400", "500"],
  style: ["normal", "italic"],
  variable: "--font-heading",
  display: "swap",
});

const fontBody = Inter_Tight({
  subsets: ["latin", "latin-ext", "cyrillic"],
  weight: ["400", "500", "600"],
  variable: "--font-body",
  display: "swap",
});

const fontMono = IBM_Plex_Mono({
  subsets: ["latin", "latin-ext", "cyrillic"],
  weight: ["400", "500"],
  variable: "--font-mono",
  display: "swap",
});

const fontHand = Caveat({
  subsets: ["latin", "latin-ext", "cyrillic"],
  weight: ["500"],
  variable: "--font-hand",
  display: "swap",
});

// Default cache lifetime for every page under [lang]. Must be a literal; keep
// equal to SANITY_REVALIDATE_SECONDS. Publishing refreshes pages earlier via
// the webhook's revalidateTag.
export const revalidate = 86400;

// Without generateStaticParams a page under [lang] is rendered on every
// request and never cached (Next.js 14).
export function generateStaticParams() {
  return LOCALES.map((lang) => ({ lang }));
}

export const metadata: Metadata = {
  metadataBase: new URL(SITE_URL),
  title: {
    default: `${SITE_NAME} — Retail and Fashion Analytics Consultant`,
    template: `%s | ${SITE_NAME}`,
  },
  description:
    "Assortment planning, retail pricing analysis and Power BI reporting for fashion and retail brands. Consultant based in Warsaw, working in English, Polish and Russian.",
};

export const viewport: Viewport = {
  themeColor: [
    { media: "(prefers-color-scheme: light)", color: "#faf8f4" },
    { media: "(prefers-color-scheme: dark)", color: "#121315" },
  ],
};

export default function LangLayout({
  children,
  params,
}: {
  children: React.ReactNode;
  params: { lang: string };
}) {
  if (!isLocale(params.lang)) notFound();

  return (
    <html lang={params.lang}>
      <body
        className={`${fontHeading.variable} ${fontBody.variable} ${fontMono.variable} ${fontHand.variable}`}
      >
        {/* Site-wide entity graph; other schema on the site references it by @id. */}
        <SchemaIdentity lang={params.lang} />

        {children}

        <GoogleAnalyticsWrapper />
        <MicrosoftClarity />
        <CustomCookieConsent lang={params.lang} />
      </body>
    </html>
  );
}
